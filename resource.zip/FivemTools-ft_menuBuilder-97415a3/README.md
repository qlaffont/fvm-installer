# ft_menuBuilder

### Prerequisites

What things you need to install this script them

 - [ft_ui](https://github.com/FivemTools/ft_ui)

### Installing

Put the folder where you want it and add it to the citmp-server.yml file

Example:

```
- ft_menuBuilder
```

### Documentation

[Exemple](https://github.com/FivemTools/ft_menuExemple)

[Wiki](https://github.com/FivemTools/ft_menuBuilder/wiki)

## License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* LH_Lawliet
* Mirardes
* JinkLeft