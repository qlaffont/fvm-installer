-- @Date:   2017-06-11T10:42:23+02:00
-- @Project: FiveM Tools
-- @Last modified time: 2017-06-13T21:11:54+02:00
-- @License: GNU General Public License v3.0

function IsOpened()
  return menus.opened
end

function Current()
  return menus.curent
end
